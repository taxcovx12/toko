<?php 

	include 'koneksi.php';

	
	session_start();

	unset($_SESSION['keranjang']);

	echo "<script>alert('berhasil hapus');</script>";
	echo "<script>location='keranjang.php';</script>";
 ?>