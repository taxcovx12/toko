-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 19, 2018 at 10:12 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 5.6.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `toko`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `level` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `username`, `password`, `nama_lengkap`, `level`) VALUES
(2, 'admin', 'admin', 'santo', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ongkir`
--

CREATE TABLE `ongkir` (
  `id_ongkir` int(11) NOT NULL,
  `kota` varchar(50) NOT NULL,
  `harga_ongkir` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ongkir`
--

INSERT INTO `ongkir` (`id_ongkir`, `kota`, `harga_ongkir`) VALUES
(1, 'jakarta', 9000),
(2, 'bogor', 9000);

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` int(11) NOT NULL,
  `email_pelanggan` varchar(100) NOT NULL,
  `password_pelanggan` varchar(50) NOT NULL,
  `nama_pelanggan` varchar(100) NOT NULL,
  `telepon_pelanggan` varchar(15) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `email_pelanggan`, `password_pelanggan`, `nama_pelanggan`, `telepon_pelanggan`, `alamat`) VALUES
(3, 'hansen@gmail.com', 'hansen', 'hansen', '08129858745', 'jalan hidup baru gang L no 56 a 002/003'),
(4, 'preka12@gmail.com', 'preka', 'preka', '08125846155', ''),
(5, 'hansen11@gmail.com', 'hansen11', 'hansen', '084165465', ''),
(6, 'santo@gmail.com', 'santo', 'santo', '0856225631', '');

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id_pembayaran` int(11) NOT NULL,
  `id_pembelian` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `bank` varchar(100) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `bukti_pembayaran` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`id_pembayaran`, `id_pembelian`, `nama`, `bank`, `jumlah`, `tanggal`, `bukti_pembayaran`) VALUES
(0, 16, 'hansen', 'Mandiri', 199002, '0000-00-00', '20180801172122jacket.jpg'),
(0, 9, 'hansen', 'mandiri', 204300, '0000-00-00', '20180801172205celana_pendek.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `pembelian`
--

CREATE TABLE `pembelian` (
  `id_pembelian` int(11) NOT NULL,
  `id_pelanggan` int(11) NOT NULL,
  `id_ongkir` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `total_pembelian` int(11) NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembelian`
--

INSERT INTO `pembelian` (`id_pembelian`, `id_pelanggan`, `id_ongkir`, `tanggal`, `total_pembelian`, `status`) VALUES
(9, 3, 1, '2018-07-18', 204300, 'Berhasil'),
(10, 3, 2, '2018-07-18', 317000, 'pending'),
(11, 3, 2, '2018-07-18', 317000, 'pending'),
(12, 3, 2, '2018-07-18', 317000, 'pending'),
(13, 3, 2, '2018-07-18', 317000, 'pending'),
(14, 6, 1, '2018-07-30', 59002, 'pending'),
(15, 3, 1, '2018-07-31', 114302, 'pending'),
(16, 3, 1, '2018-08-01', 199002, 'pending'),
(17, 3, 1, '2018-08-01', 199002, 'pending'),
(18, 3, 2, '2018-08-01', 254302, 'pending'),
(19, 3, 1, '2018-08-01', 254302, 'pending'),
(20, 3, 1, '2018-08-01', 309602, 'pending'),
(21, 3, 1, '2018-08-05', 59002, 'pending'),
(22, 1, 1, '2018-11-12', 59002, 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `pembelian_produk`
--

CREATE TABLE `pembelian_produk` (
  `id_pembelian_produk` int(11) NOT NULL,
  `id_pembelian` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembelian_produk`
--

INSERT INTO `pembelian_produk` (`id_pembelian_produk`, `id_pembelian`, `id_produk`, `jumlah`) VALUES
(4, 9, 5, 2),
(5, 10, 6, 2),
(6, 10, 7, 1),
(7, 11, 6, 2),
(8, 11, 7, 1),
(9, 12, 6, 2),
(10, 12, 7, 1),
(11, 13, 6, 2),
(12, 13, 7, 1),
(14, 15, 3, 1),
(18, 17, 4, 1),
(19, 17, 5, 2),
(20, 18, 4, 1),
(21, 18, 5, 2),
(22, 18, 3, 1),
(23, 19, 4, 1),
(24, 19, 5, 2),
(25, 19, 3, 1),
(26, 20, 4, 1),
(27, 20, 5, 2),
(28, 20, 3, 2),
(29, 21, 4, 1),
(30, 22, 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id_produk` int(11) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `harga_produk` int(11) NOT NULL,
  `berat` int(11) NOT NULL,
  `foto_produk` varchar(100) NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id_produk`, `nama_produk`, `harga_produk`, `berat`, `foto_produk`, `deskripsi`) VALUES
(3, 'sepatu', 55300, 400, 'sepatu.jpg', 'ini adalah sepatu bagus\r\n'),
(4, 'jacket baseball', 50002, 123, 'jacket.jpg', 'jacket baseball murah'),
(5, 'celana pendek', 70000, 400, 'celana_pendek.jpg', 'ini celana pendek dengan kualitas bagus'),
(6, 'celana denim', 100000, 600, 'celana3.jpg', 'celana panjang dengan kualitas 100% denim'),
(7, 'celana bahan', 108000, 400, 'celana2.jpg', 'celana bahan 100% cotton'),
(8, 'kaos polos', 50000, 100, 'kaos_polos.jpg', 'ini kaos polos bagus'),
(9, 'kaos kerah', 55000, 100, 'kaos_kerah.jpeg', 'kaos kerah baguss'),
(10, 'sepatu pantofel', 230000, 200, 'sepatu_pantofel.jpg', 'sepatu pantofel ok'),
(11, 'jacket levis', 120000, 130, 'jacket_levis.jpg', 'jacket levis ori');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `ongkir`
--
ALTER TABLE `ongkir`
  ADD PRIMARY KEY (`id_ongkir`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indexes for table `pembelian`
--
ALTER TABLE `pembelian`
  ADD PRIMARY KEY (`id_pembelian`);

--
-- Indexes for table `pembelian_produk`
--
ALTER TABLE `pembelian_produk`
  ADD PRIMARY KEY (`id_pembelian_produk`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ongkir`
--
ALTER TABLE `ongkir`
  MODIFY `id_ongkir` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id_pelanggan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `pembelian`
--
ALTER TABLE `pembelian`
  MODIFY `id_pembelian` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `pembelian_produk`
--
ALTER TABLE `pembelian_produk`
  MODIFY `id_pembelian_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
