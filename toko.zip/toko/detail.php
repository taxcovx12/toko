<?php 
	
	include 'koneksi.php';
	session_start();
    $id_produk = $_GET['id'];  
	$ambil = $koneksi->query("SELECT * FROM produk WHERE id_produk='$_GET[id]'");
	$pecah = $ambil->fetch_assoc();

 ?>
 <!DOCTYPE html>
<html>
<head>
	<title>Toko</title>
	<link rel="stylesheet" type="text/css" href="admin/assets/css/bootstrap.css">
</head>
<body>

<!----- navbar--->
	<nav class="navbar navbar-default">
			<div class="container">
				<ul class="nav navbar-nav">
					<li><a href="index.php">Home</a></li>
					<li><a href="keranjang.php">Keranjang</a></li>
					<li><a href="checkout.php?">Checkout</a></li>
					<?php if (isset($_SESSION['pelanggan'])): ?>
					<li><a href="logout.php">Logout</a></li>
					<?php else: ?>
					<li><a href="login.php">Login</a></li>
					<li><a href="daftar.php">Daftar</a></li>
					<?php endif ?>
				
				</ul>
			</div>
	</nav>


	<section class="konten"> 
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<img src="admin/foto_produk/<?php echo $pecah['foto_produk']; ?>" class="img-responsive">
				</div>
				<div class="col-md-6">
					<h2><?php echo $pecah['nama_produk']; ?></h2>
					<h4>Rp. <?php echo number_format($pecah['harga_produk']) ?></h4>
					<h4>Berat : <?php echo $pecah['berat']; ?></h4>
					<p>Deskripsi : <?php echo $pecah['deskripsi']; ?></p>
					<form method="post">
						<div class="form-group">
							<label>Jumlah</label>
							<input type="number" min="1" name="jumlah" class="form-control">
							<button name="beli" class="btn btn-primary">Beli</button>
						</div>
					</form>
					<?php 

						if (isset($_POST['beli'])) {
							$jumlah = $_POST['jumlah'];
							$_SESSION['keranjang'][$id_produk] += $jumlah;

							echo "<script>alert('produk telah dimasukan di keranjang');</script>";
							echo "<script>location='keranjang.php';</script>";
						}

					 ?>
				</div>
		</div>
	</section>
</body>
</html>