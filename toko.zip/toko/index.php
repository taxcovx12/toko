<?php 
   
   include 'koneksi.php';
    
   
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Toko</title>
	<link rel="stylesheet" type="text/css" href="admin/assets/css/bootstrap.css">
	<link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
   <script type="text/javascript" src="admin/assets/jquery.js"></script>
   <script type="text/javascript" src="admin/assets/js/bootstrap.min.js"></script>

</head>
<body>
	

	<?php 
 		include 'header.php';
 	?>
	<!---- promo---->
	
	<section class="promo">  
		<div class="container">
			<div class="col-sm-12">
				<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
				  <!-- Indicators -->
				  <ol class="carousel-indicators">
				    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
				    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
				    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
				  </ol>

				  <!-- Wrapper for slides -->
				  <div class="carousel-inner" role="listbox">
				    <div class="item active">
				      <img src="admin/foto_produk/diskon70.jpg" alt="promo" width="1500">
				    </div>
				    <div class="item">
				      <img src="admin/foto_produk/weekend.png" alt="promo" width="1600">
				    </div>
				    <div class="item">
				    	<img src="admin/foto_produk/diskonadidas.png" alt="promo" width="1500">
				    </div>
				  </div>

				  <!-- Controls -->
				  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
				    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
				    <span class="sr-only">Previous</span>
				  </a>
				  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
				    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
				    <span class="sr-only">Next</span>
				  </a>
				</div>
			</div>
		</div>
	</section>

	<!----- container ------->
	<section class="konten">
		<div class="container">
			<h1>Produk Terbaru</h1>
				<div class="row">
				<?php $ambil = $koneksi->query("SELECT * FROM produk ") or die("mysql_error"); ?>
				<?php  while($pecah = $ambil->fetch_assoc()) { ?>
				
					<div class="col-md-3">
						<div class="thumbnail">
							<img src="admin/foto_produk/<?php echo $pecah['foto_produk']; ?> " width="200" >
							<div class="caption">
								<h3><?php echo $pecah['nama_produk']; ?></h3>
								<h5>Harga Rp. <?php echo number_format($pecah['harga_produk']); ?></h5>
								<a href="beli.php?id=<?php echo $pecah['id_produk']; ?>" class="btn btn-primary">Beli</a>
								<a href="detail.php?id=<?php echo $pecah['id_produk'] ?>" class="btn btn-info">Detail</a>
							</div>
						</div>
					</div>
				
			<?php } ?>
				
				</div>
				<nav aria-label="Page navigation example" align="center">
	                  <ul class="pagination">
	                    <li class="page-item">
	                      <a class="page-link" href="#" aria-label="Previous">
	                        <span aria-hidden="true">&laquo;</span>
	                        <span class="sr-only">Previous</span>
	                      </a>
	                    </li>
	                    <li class="page-item"><a class="page-link" href="#">1</a></li>
	                    <li class="page-item"><a class="page-link" href="#">2</a></li>
	                    <li class="page-item"><a class="page-link" href="#">3</a></li>
	                    <li class="page-item">
	                      <a class="page-link" href="#" aria-label="Next">
	                        <span aria-hidden="true">&raquo;</span>
	                        <span class="sr-only">Next</span>
	                      </a>
	                    </li>
	                  </ul>
	                </nav>
		</div>
	</section>

	<!------Official Store----->
	<section class="offical">
		<div class="container">
			<h2>Official Store</h2>
			<div class="row">
				<div class="col-md-2">
					<div class="thumbnail">
						<img src="admin/foto_produk/corsair.jpg" width="200" class="img-responsive">
					</div>
				</div>
				<div class="col-md-2">
					<div class="thumbnail">
						<img src="admin/foto_produk/asus.jpg" width="200" class="img-responsive">
					</div>
				</div>
				<div class="col-md-2">
					<div class="thumbnail">
						<img src="admin/foto_produk/lenovo.jpg" width="200" class="img-responsive">
					</div>
				</div>
				<div class="col-md-2">
					<div class="thumbnail">
						<img src="admin/foto_produk/amd.jpg" width="200" class="img-responsive">
					</div>
				</div>
			</div>
		</div>
	</section>

	 <footer class="footer text-center">
        Copyright &copy;2018 Designed by <a href="#">Santo</a>
    </footer>
<!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="admin/assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="admin/assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="admin/assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="admin/assets/js/custom.js"></script>
    
</body>
</html>