<?php 
	include 'koneksi.php';
 ?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
	<!-- BOOTSTRAP STYLES-->
    <link href="admin/assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="admin/assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="admin/assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
	<div class="navbar navbar-inverse">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target='#bs-example-navbar-collapse-1' aria-expanded="false">
					<span class="sr-only">Toggle navigation</span>	
					<span class="icon-bar"></span>	
					<span class="icon-bar"></span>	
					<span class="icon-bar"></span>	
				</button>
				<a href="index.php">
					<img src="admin/foto_produk/images1.jpg" alt="brand">
				</a>
			</div>
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

				<ul class="nav navbar-nav">
					<li><a href="index.php">Home</a></li>
					<li><a href="keranjang.php">Keranjang</a></li>
					<li><a href="checkout.php?">Checkout</a></li>
					<?php if (isset($_SESSION['pelanggan'])): ?>
					<li><a href="logout.php">Logout</a></li>
					<?php else: ?>
					<li><a href="login.php">Login</a></li>
					<li><a href="daftar.php">Daftar</a></li>
					<?php endif ?>
				</ul>
				
				<ul class="nav navbar-nav navbar-right">
			        <form class="navbar-form navbar-left" method="post" id="search_text">
				        <div class="form-group">
				          <input type="text" class="form-control" placeholder="Search" name="nama">
				        </div>
				        <button type="submit" name="cari" class="btn btn-info">Cari</button>
				        <div id="result"></div>
				    </form>
			      </ul>
			      <script>
			      	$(document).ready(function() {
			      		$('#search_text').keyup(function(){
			      			var txt = $(this).val();
			      			if (txt != '') {

			      			}else{
			      				$('#result').html('');
			      				$.ajax({
			      					url:"fetch.php",
			      					method:"post",
			      					data:{search:txt},
			      					dataType:text,
			      					success:function(data){
			      						$('#result').html(data);
			      					}
			      				});
			      			}
			      		});
			      	});
			      </script>
			</div>
		</div>
	</div>

	
	
</body>
</html>
