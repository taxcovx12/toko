<?php 
	session_start();

	include 'koneksi.php';
	$ambil = $koneksi->query("SELECT * FROM pelanggan");
	$pecah = $ambil->fetch_assoc();
 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title>Login</title>
 	<link rel="stylesheet" type="text/css" href="admin/assets/css/bootstrap.css">
 </head>
 <body>

 	<?php 
 		include 'header.php';
 	?>

	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h3 class="panel-title">Login Pelanggan</h3>
					</div>
					<div class="panel-body">
						<form method="post">
							<div class="form-group">
								<label>Email</label>
								<input type="email" name="email" class="form-control">
							</div>
							<div class="form-group">
								<label>Password</label>
								<input type="password" name="password" class="form-control">
							</div>
							<button class="btn btn-primary" name="login">Login</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php 
	if (isset($_POST['login'])) {
		$email = $_POST['email'];
		$password = $_POST['password'];
		$ambil = $koneksi->query("SELECT * FROM pelanggan WHERE email_pelanggan='$email' AND password_pelanggan='$password'");
		$benar = $ambil->num_rows;


		if ($benar) {

			$pecah = $ambil->fetch_assoc();
			$_SESSION['pelanggan'] = $pecah;


			echo "<script>alert('Anda Berhasil login');</script>";
			if (isset($_SESSION["keranjang"]) OR !empty($_SESSION['keranjang'])) {
				echo "<script>location='checkout.php';</script>";
			}
			else{
				echo "<script>location='riwayat.php';</script>";
			}
			
		}
		else{
			echo "<script>alert('Anda Gagal login,Periksa kembali Email dan Password');</script>";
			echo "<script>location='login.php';</script>";
		}
	}

	 ?>

 </body>
 </html>