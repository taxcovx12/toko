<?php
	include 'koneksi.php';	

	session_start();
	$ambil = $koneksi->query("SELECT * FROM pembelian JOIN pelanggan ON pembelian.id_pelanggan =pelanggan.id_pelanggan WHERE pembelian.id_pembelian='$_GET[id]'");

	$pecah = $ambil->fetch_assoc();
	$ongkir = $pecah['id_ongkir'];

 ?>
 
<!DOCTYPE html>
 <html>
 <head>
 	<title>Nota Belanja</title>
 	<link rel="stylesheet" type="text/css" href="admin/assets/css/bootstrap.css">
 </head>
 <body>

 	<?php 
 		include 'header.php';
 	?>





	 <pre><?php print_r($pecah); ?></pre>
	 <pre><?php print_r($_SESSION); ?></pre>
	 <?php 
	 	$id_pelanggan = $pecah['id_pelanggan'];
	 	$id_benar = $_SESSION['pelanggan']['id_pelanggan'];

	 	if ($id_pelanggan !== $id_benar) {
	 		echo "<script>alert('anda tidak Berhak mengakses ini');</script>";
	 		echo "<script>location='riwayat.php';</script>";
	 		exit();
	 	}


	  ?>
	

<div class="container">
	<h2>Detail Pembelian <strong><?php echo $pecah['nama_pelanggan']; ?></strong></h2>
	<h3>Tanggal : <?php echo $pecah['tanggal']; ?></h3>
	 <table class="table table-bordered">
	 	<thead>
	 		<tr>
	 			<th>No</th>
	 			<th>Nama Produk</th>
	 			<th>Harga</th>
	 			<th>Jumlah</th>
	 			<th>Sub Total</th>
	 		</tr>
	 	</thead>
	 	<tbody>
	 		<?php $no=1; ?>
	 		<?php $total=0; ?>
	 		<?php $beli = $koneksi->query("SELECT * FROM pembelian_produk JOIN produk ON pembelian_produk.id_produk=produk.id_produk WHERE pembelian_produk.id_pembelian='$_GET[id]'"); ?>
	 		<?php while($baru = $beli->fetch_assoc()) { ?>
	 		<?php $subtotal = $baru['harga_produk'] *$baru['jumlah'] ; ?>

	 		<tr>
	 			<td><?php echo $no; ?></td>
	 			<td><?php echo $baru['nama_produk']; ?></td>
	 			<td>Rp. <?php echo number_format($baru['harga_produk']); ?></td>
	 			<td><?php echo $baru['jumlah']; ?></td>
	 			<td>Rp. <?php echo number_format($baru['harga_produk']*$baru['jumlah']); ?></td>
	 		</tr>
	 		
	 		<?php $no++; ?>
	 		 <?php $total += $subtotal  ?>
	 		<?php } ?>
	 	</tbody>
	 	<tfoot>

	 		<tr>
	 			<td colspan="4">Total Belanja</td>
				<td>Rp. <?php echo number_format($total); ?></td>
	 		</tr>
	 		
	 		<?php $ambil_ongkos = $koneksi->query("SELECT * FROM ongkir WHERE id_ongkir = '$ongkir'"); ?>
	 		<?php $ongkos = $ambil_ongkos->fetch_assoc() ?>
	 		
	 		<tr>
	 			<td colspan="4">Biaya</td>
	 			<td>Rp. <?php echo number_format($ongkos['harga_ongkir']); ?></td>
	 		</tr>
	 		
			<tr>
				<th colspan="4">Total Yang di Bayar </th>
				<th>Rp . <?php echo number_format($pecah['total_pembelian']) ?> </th>
			</tr>
		</tfoot>
	 </table>
	 <div class="alert alert-info">Silakan melakukan pembayaran Rp. <?php echo number_format($pecah['total_pembelian']); ?> ke BANK BCA 4870501183 A/N Susanto Halim</div>
	 <a href="pembayaran.php?id=<?php echo $_GET['id']; ?>" class="btn btn-success">Pembayaran</a>
	
</div>
</body>
</html>