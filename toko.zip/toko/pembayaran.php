<?php 
   
   session_start();

   include 'koneksi.php';
    
  	 if (!isset($_SESSION['pelanggan']) OR empty($_SESSION['pelanggan']) ) {
   		echo "<script>alert('silakan login');</script>" ;
   		echo "<script>location='login.php';</script>" ;
   		exit();
   }


   $ambil = $koneksi->query("SELECT * FROM pembelian WHERE id_pembelian = '$_GET[id]'");
   $pecah = $ambil->fetch_assoc();


 ?>
<pre><?php print_r($_SESSION) ?></pre>
<pre><?php print_r($pecah); ?></pre>
<?php 
	 	$id_pelanggan = $pecah['id_pelanggan'];
	 	$id_benar = $_SESSION['pelanggan']['id_pelanggan'];

	 	if ($id_pelanggan !== $id_benar) {
	 		echo "<script>alert('anda tidak Berhak mengakses ini');</script>";
	 		echo "<script>location='riwayat.php';</script>";
	 		exit();
	 	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Pembayaran</title>
	<link rel="stylesheet" type="text/css" href="admin/assets/css/bootstrap.css">
</head>
<body>

	<?php 
 		include 'header.php';
 	?>

	<div class="container">
		<h2>Konfirmasi Pembayaran</h2>
		<h3 class="alert alert-info">Jumlah Pembayaran anda adalah <strong>Rp. <?php echo number_format($pecah['total_pembelian']); ?></strong></h3>
		<h3>Upload File pembayaran Di sini</h3>
		<form method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label>Nama Penyetor</label>
				<input type="text" name="nama" class="form-control">
			</div>
			<div class="form-group">
				<label>Bank</label>
				<input type="text" name="bank" class="form-control"> 
			</div>
			<div class="form-group">
				<label>Jumlah</label>
				<input type="number" name="jumlah" class="form-control" min="1">
			</div>
			<div class="form-group">
				<label>Foto Bukti</label>
				<input type="file" name="bukti" class="form-control">
				<p class="alert alert-danger">Foto bukti harus JPG Maksimal 2MB</p>
			</div>
			<button class="btn btn-primary" name="kirim">Kirim</button>
		</form>
		<?php 

			if (isset($_POST['kirim'])) {
				
				$namafoto = $_FILES["bukti"]["name"];
				$lokasifoto = $_FILES["bukti"]["tmp_name"];
				$namafotofiks = date("YmdHis").$namafoto;
				move_uploaded_file($lokasifoto, "foto_pembayaran/$namafotofiks");
				$tanggal = date("d-m-Y");

				$koneksi->query("INSERT INTO pembayaran (id_pembelian, nama, bank, jumlah, tanggal, bukti_pembayaran) VALUES ('$_GET[id]', '$_POST[nama]', '$_POST[bank]', '$_POST[jumlah]', '$tanggal', '$namafotofiks'  )");

				$koneksi->query("UPDATE pembelian SET status = 'Berhasil' WHERE id_pembelian = '$_GET[id]'");

				echo "<script>alert('Berhasil Melakukan Pembayaran');</script>";
	 			echo "<script>location='riwayat.php';</script>";
			}

		 ?>	
	</div>
</body>
</html>