<?php 

	include 'koneksi.php';
	$output = '';
	$ambil = $koneksi->mysql("SELECT * FROM produk WHERE nama_produk LIKE '%."$_POST['search']".%'");
	if ($ambil->num_rows > 0) {
		$output .= '<h4 align="center">Search Result</h4>';
		$output .= '<div class="table-responsive">
					<table>
						<tr>
							<th>Nama Produk</th>
							<th></th>
						</tr>';
		while($pecah = $ambil->fetch_assoc()){
			$output .= '<tr>
						<td>.$pecah["nama_produk"]</td>
					</tr>
					</table>
					</div>';
		}
		echo $output;
	}else{
		echo "data not found";
	}
 ?>
 
	