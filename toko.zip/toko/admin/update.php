<h2>Update Produk</h2>

<?php 
	
	$ambil = $koneksi->query("SELECT * FROM mesin WHERE id_mesin = '$_GET[id]'");
	$pecah = $ambil->fetch_assoc();

 ?>

<form method="post" enctype="multipart/form-data">
	<div class="form-group">
		<label>Type mesin</label>
		<input type="text" name="tipe" class="form-control" value="<?php echo $pecah['tipe']; ?>">
	</div>
	<div class="form-group">
		<label>Kategori</label>
		<select class="form-control" name="kategori">
			<option value="1">Manual</option>
			<option value="2">Semi_automatic</option>
			<option value="3">Automatic</option>
		</select>
	</div>
	<div class="form-group">
		<label>Jenis Mesin</label>
		<select class="form-control" name="id_jenis">
		</select>
	</div>
	<div class="form-group">
		<label>Rating</label>
		<select class="form-control" name="rating">
			<option value="<?php echo $pecah['rating'] ?>"><?php echo $pecah['rating']; ?></option>
		</select>
	</div>
	<div class="form-group">
		<label>Status</label>
		<input type="number" name="status" class="form-control" value="<?php echo $pecah['status']; ?>">
	</div>
	<div class="form-group">
		<label>Video</label>
		<input type="text" name="video" class="form-control" value="<?php echo $pecah['video']; ?>">
	</div>
	<div class="form-group">
		<label>Gambar</label>
		<input type="file" name="gambar" class="form-control">
	</div>
	<div class="form-group">
		<label>Gambar1</label>
		<input type="file" name="gambar1" class="form-control">
	</div>
	<div class="form-group">
		<label>Gambar2</label>
		<input type="file" name="gambar2" class="form-control">
	</div>
	<div class="form-group">
		<label>Gambar3</label>
		<input type="file" name="gambar3" class="form-control">
	</div>
	<div class="form-group">
		<label>Detail</label>
		<textarea rows="7" cols="3" class="form-control" name="detail"><?php echo $pecah['detail']; ?></textarea>
	</div>
	<div class="form-group">
		<label>Deskripsi</label>
		<textarea rows="7" cols="3" class="form-control" name="deskripsi"><?php echo $pecah['deskripsi']; ?></textarea>
	</div>
	
	<input type="submit" name="submit" value="Simpan" class="btn btn-primary">
	<input type="reset" name="reset" value="Reset">
</form>

<?php 
	
	if (isset($_POST['submit'])) {
		$nama = $_FILES['gambar']['name'];
		$lokasi = $_FILES['gambar']['tmp_name'];

		$nama1 = $_FILES['gambar1']['name'];
		$lokasi1 = $_FILES['gambar1']['tmp_name'];
		
		$nama2 = $_FILES['gambar2']['name'];
		$lokasi2 = $_FILES['gambar2']['tmp_name'];
		
		$nama3 = $_FILES['gambar3']['name'];
		$lokasi3 = $_FILES['gambar3']['tmp_name'];
		
		$tipe= $_POST['tipe'];
		$id_kategori = $_POST['kategori'];
		$id_jenis = $_POST['id_jenis'];
		$rating =$_POST['rating'];
		$status =$_POST['status'];
		$detail = $_POST['detail'];
		$deskripsi = $_POST['deskripsi'];
		$video = $_POST['video'];

		move_uploaded_file($lokasi, "assets/img/shop/produk/".$nama);
		move_uploaded_file($lokasi1, "assets/img/produk/".$nama1);
		move_uploaded_file($lokasi2, "assets/img/produk/".$nama2);
		move_uploaded_file($lokasi3, "assets/img/produk/".$nama3);
			
		$koneksi->query("INSERT INTO mesin (id_kategori, id_jenis, jenis_mesin, tipe, gambar, detail, video, rating, status, gambar1, gambar2, gambar3, deskripsi) VALUES('$id_kategori', '$id_jenis', '$jenis_mesin', '$tipe', '$nama', '$detail', '$video', '$rating', '$status', '$nama1', '$nama2', '$nama3', '$deskripsi')");
		
		echo "<script>alert('data tersimpan');</script>";
		echo "<meta http-equiv='refresh' content='1;url=index?hal=tampil'>";

		
		
		}
	


 ?>