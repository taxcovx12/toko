<h2>Edit Produk</h2>

<?php 

	$ambil = $koneksi->query("SELECT * FROM produk WHERE id_produk='$_GET[id]'");
	$pecah = $ambil->fetch_assoc();

	echo "<pre>";
	print_r($pecah);
	echo "</pre>";

 ?>

 <form method="post" enctype="multipart/form-data">
	<div class="form-group" >  
		<label>Nama</label>
		<input type="text" name="nama" class="form-control" value="<?php echo $pecah['nama_produk']?>">
	</div>
	<div class="form-group">
		<label>Harga (Rp)</label>
		<input type="number" name="harga" class="form-control" value="<?php echo $pecah['harga_produk']?>">
	</div>
	<div class="form-group">
		<label>Berat (Gr)</label>
		<input type="number" name="berat" class="form-control" value="<?php echo $pecah['berat']?>">
	</div>
	<div class="form-group">
		<label>Deskripsi</label>
		<textarea class="form-control" rows="10" name="deskripsi" ><?php echo $pecah['deskripsi']?></textarea>
	</div>
	<div class="form-group">
		<img src="foto_produk/<?php echo $pecah['foto_produk']?>" width="200">
	</div>
	<div class="form-group">
		<label>Foto</label>
		<input type="file" name="foto" class="form-control">
	</div>
	<input type="submit" class="btn btn-primary" name="ubah" value="Ubah">
</form>

<?php 

	if (isset($_POST['ubah'])) {
		
		$nama = $_FILES['foto']['name'];
		$lokasi = $_FILES['foto']['tmp_name'];
		if (!empty($lokasi)) {
			move_uploaded_file($lokasi, "foto_produk/".$nama);

			$koneksi->query("UPDATE produk SET nama_produk='$_POST[nama]', harga_produk='$_POST[harga]', berat='$_POST[berat]', foto_produk='$nama', deskripsi='$_POST[deskripsi]' WHERE id_produk='$_GET[id]'");
		}
		else{
			$koneksi->query("UPDATE produk SET nama_produk='$_POST[nama]', harga_produk='$_POST[harga]', berat='$_POST[berat]', deskripsi='$_POST[deskripsi]' WHERE id_produk='$_GET[id]'");
		}
		echo "<script>alert('data berhasil di ubah');</script>";
		echo "<script>location='index.php?halaman=produk';</script>";
	}

 ?>