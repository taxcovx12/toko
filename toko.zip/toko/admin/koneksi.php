<?php 

	
    $koneksi = new mysqli("localhost","root","","toko")or die("gagal koneksi");


 ?>