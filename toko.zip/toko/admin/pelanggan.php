<h2>ini adalah pelanggan</h2>

<table class="table table-bordered">
	<thead>
		<tr>
			<th>No</th>
			<th>Nama</th>
			<th>Email</th>
			<th>no telp</th>
			<th>aksi</th>
		</tr>
	</thead>
	<tbody>
		<?php $no =1; ?>
		<?php $ambil = $koneksi->query("SELECT *FROM pelanggan"); ?>
		<?php while ($pecah = $ambil->fetch_assoc()) { ?>
		<tr>
			<td><?php echo $no; ?></td>
			<td><?php echo $pecah['nama_pelanggan']; ?></td>
			<td><?php echo $pecah['email_pelanggan']; ?></td>
			<td><?php echo $pecah['telepon_pelanggan']; ?></td>
			<td>
				<a href="index.php?halaman=hapus_pelanggan&id=<?php echo$pecah['id_pelanggan']; ?>" class="btn btn-danger">Hapus</a>
			</td>
		</tr>
	<?php $no++; ?>
	<?php } ?>
	</tbody>
</table>
<a href="index.php?halaman=tambah_pelanggan" class="btn btn-primary">Tambah</a>