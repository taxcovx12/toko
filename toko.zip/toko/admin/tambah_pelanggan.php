<h2>Tambah pelanggan</h2>

<form method="post" enctype="multipart/form-data">
	<div class="form-group" >  
		<label>Nama</label>
		<input type="text" name="nama" class="form-control">
	</div>
	<div class="form-group">
		<label>Email</label>
		<input type="email" name="email" class="form-control">
	</div>
	<div class="form-group">
		<label>No telp</label>
		<input type="number" name="notelp" class="form-control">
	</div>
	<input type="submit" class="btn btn-primary" name="save" value="Simpan">
</form>
<?php 

	if (isset($_POST['save'])) {
		
	
		$name = $_POST['nama'];
		$email = $_POST['email'];
		$notelp = $_POST['notelp'];

		$koneksi->query("INSERT INTO pelanggan (nama_pelanggan, email_pelanggan, telepon_pelanggan ) VALUES ('$name', '$email', '#notelp')");
	
		echo "<div class='alert alert-info'>Data tersimpan</div>";
 		echo "<meta http-equiv='refresh' content='1;url=index.php?halaman=pelanggan'>";

	}

 ?>