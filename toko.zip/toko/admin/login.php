<?php 
    session_start();

    include 'koneksi.php';
    $ambil = $koneksi->query("SELECT * FROM admin");
    $pecah = $ambil->fetch_assoc();
 ?>

 <!DOCTYPE html>
 <html>
 <head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
 </head>
 <body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Admin</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Last access : <?php echo date('d m Y'); ?> <a href="index.php?halaman=logout" class="btn btn-danger square-btn-adjust">Logout</a> </div>
        </nav>
    </div>   


    <div class="container" style="margin-top: 30px;">
        
        <div class="row">
            <div class="col-md-4">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Login Pelanggan</h3>
                    </div>
                    <div class="panel-body">
                        <form method="post">
                            <div class="form-group">
                                <label>Username</label>
                                <input type="text" name="username" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input type="password" name="password" class="form-control">
                            </div>
                            <button class="btn btn-primary" name="login">Login</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php 
    if (isset($_POST['login'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];
        $ambil = $koneksi->query("SELECT * FROM admin WHERE username='$username' AND password='$password'");
        $benar = $ambil->num_rows;


        if ($benar > 0) {

            $pecah = $ambil->fetch_assoc();
            $_SESSION['admin'] = $pecah;


            echo "<script>alert('Anda Berhasil login');</script>";
            echo "<script>location='index.php';</script>";

            }else{
                 echo "<script>alert('Anda Gagal Login');</script>";
                 echo "<script>location='login.php';</script>";
            }
            
        }
        
           
          

     ?>

 </body>
 </html>