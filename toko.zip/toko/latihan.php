<!DOCTYPE html>
<html>
<head>
	<title>belajar jquery</title>
	<script type="text/javascript" src="jquery-3.3.1.js"></script>
</head>
<body>
	<script type="text/javascript">
		$(document).ready(function(){
			$(#tombol).ready(function(){
				$(this).after("<p>sedang belajar jquery </p>");
			});
		});
	</script>
</body>
</html>